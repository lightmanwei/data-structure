#include "btree.h"

int main(void) {

    BTree LList[LLIST_SIZE] = {NULL};
    int list_num;
    CreateBiTree(LList[0], init_btree_array);
    BTree result;
    int location;
    ElemType e;
    bool lr;
    int op = 1;
    while (op) {
        system("clear");
        printf("\n\n");
        printf("选择一个线性表(输入序号，默认1-10)\n");
        scanf("%d", &list_num);
        printf("      Menu for Linear Table On Sequence Structure \n");
        printf("-------------------------------------------------\n");
        printf("    	  1. CreateBiTree       8. "
               "GetSibling\n");
        printf("    	  2. DestroyBiTree    9. InsertNode \n");
        printf("    	  3. ClearBiTree      10. DeleteNode\n");
        printf("    	  4. BiTreeEmpty      11. PreOrderTraverse\n");
        printf("    	  5. BiTreeDepth     12. InOrderTraverse\n");
        printf("    	  6. LocateNode        13. PostOrderTraverse\n");
        printf("    	  7. Assign     14. LevelOrderTraverse\n");
        printf("    	  15. GraphBTree     16. "
               "FileWrite\n");
        printf("    	  17. FileRead       0. Exit\n");
        printf("-------------------------------------------------\n");
        printf("    请选择你的操作[0~14]:");
        scanf("%d", &op);
        switch (op) {
            case 1:
                //printf("\n----IntiList功能待实现！\n");
                if (CreateBiTree(LList[list_num - 1],
                                 init_btree_array) ==
                    OK)
                    printf("二叉树创建成功！\n");
                else printf("二叉树创建失败！\n");
                getchar();
                getchar();
                break;
            case 2:
                //printf("\n----DestroyList功能待实现！\n");
                if (DestroyBiTree(LList[list_num - 1]) ==
                    OK)
                    printf("二叉树销毁成功！\n");
                else printf("二叉树销毁失败！\n");
                getchar();
                getchar();
                break;
            case 3:
                //printf("\n----ClearList功能待实现！\n");
                if (ClearBiTree(LList[list_num - 1]) == OK)
                    printf("二叉树清空成功！\n");
                else printf("二叉树清空失败！\n");
                getchar();
                getchar();
                break;
            case 4:
                //printf("\n----ListEmpty功能待实现！\n");
                if (BiTreeEmpty(LList[list_num - 1]) ==
                    TRUE)
                    printf("二叉树为空！\n");
                else printf("二叉树不为空！\n");
                getchar();
                getchar();
                break;
            case 5:
                //printf("\n----ListLength功能待实现！\n");
                printf("二叉树的深度为：%d",
                       BiTreeDepth(LList[list_num - 1]));
                getchar();
                getchar();
                break;
            case 6:
                if (!LList[list_num - 1]) {
                    printf("二叉树为空\n");
                    break;
                }
                printf("获取元素的位置是：\n");
                scanf("%d", &location);
                result = LocateNode(
                        LList[list_num - 1]->lchild,
                        location);
                if (result)
                    printf("二叉树第%d个元素的data是%d\n",
                           location,
                           result->elem.data);
                else printf("没有目标元素\n");
                getchar();
                getchar();
                break;
            case 7:
                printf("更改的元素的id是：\n");
                scanf("%d", &location);
                printf("赋予的值为：\n");
                scanf("%d", &e);
                if (Assign(LList[list_num - 1], location, e)
                        )
                    printf
                            ("更改成功\n");
                else printf("没有%d元素\n", location);
                getchar();
                getchar();
                break;
            case 8:
                printf("要获取兄弟节点的节点的id是：\n");
                scanf("%d", &location);
                result = GetSibling(LList[list_num - 1],
                                    location);
                if (result)
                    printf("目标节点的兄弟节点的data是%d\n",
                           result->elem.data);
                else printf("目标节点无兄弟节点\n");
                getchar();
                getchar();
                break;
            case 9:
                if (!LList[list_num - 1]) {
                    printf("二叉树为空\n");
                    break;
                }
                printf("要插入的位置是\n");
                scanf("%d", &location);
                printf("要插入的是左0还是右1\n");
                scanf("%d", &lr);
                printf("节点的data为\n");
                scanf("%d", &e);
                result = (BTree) malloc(sizeof(BTreeNode));
                result->elem.data = e;
                if (InsertNode(LList[list_num - 1]->lchild,
                               location,
                               lr, result) == OK)
                    printf("插入成功\n");
                else printf("插入失败\n");
                getchar();
                getchar();
                break;
            case 10:
                if (!LList[list_num - 1]) {
                    printf("二叉树为空\n");
                    break;
                }
                printf("删除节点的id是：\n");
                scanf("%d", &location);
                if (DeleteNode(LList[list_num - 1],
                               location) == OK)
                    printf("删除成功\n");
                else printf("删除失败\n");
                getchar();
                getchar();
                break;
            case 11:
                if (!LList[list_num - 1]) {
                    printf("二叉树为空\n");
                    break;
                }
                PreOrderTraverse(
                        LList[list_num - 1]->lchild);
                printf("\n");
                getchar();
                getchar();
                break;
            case 12:
                if (!LList[list_num - 1]) {
                    printf("二叉树为空\n");
                    break;
                }
                InOrderTraverse(
                        LList[list_num - 1]->lchild);
                printf("\n");
                getchar();
                getchar();
                break;
            case 13:
                if (!LList[list_num - 1]) {
                    printf("二叉树为空\n");
                    break;
                }
                PostOrderTraverse(
                        LList[list_num - 1]->lchild);
                printf("\n");
                getchar();
                getchar();
                break;
            case 14:
                if (!LList[list_num - 1]) {
                    printf("二叉树为空\n");
                    break;
                }
                LevelOrderTraverse(
                        LList[list_num - 1]->lchild);
                printf("\n");
                getchar();
                getchar();
                break;
            case 15:
                if (!LList[list_num - 1]) {
                    printf("二叉树为空\n");
                    break;
                }
                Display(LList[list_num - 1]->lchild, 0);
                printf("\n");
                getchar();
                getchar();
                break;
            case 16:
                if (!LList[list_num - 1]) {
                    printf("二叉树为空\n");
                    break;
                }
                if (f_write(LList[list_num - 1]->lchild,
                            FILE_NAME) == OK)
                    printf("写入文件成功\n");
                else printf("写入文件失败\n");
                getchar();
                getchar();
                break;
            case 17:
                //f_read
                if (f_read(LList[list_num - 1],
                           FILE_NAME) == OK)
                    printf("读取线性表成功\n");
                else printf("读取线性表失败\n");
                getchar();
                getchar();
                break;

            case 0:
                break;
        }
        //end of switch
        if (!LList[list_num - 1]) {
            printf("二叉树为空\n");
        } else
            Display(LList[list_num - 1]->lchild,
                    0);
    }//end of while
    printf("欢迎下次再使用本系统！\n");
}




